#pragma once

#define HTTP_SERVER "107.160.244.5"
#define HTTP_PORT 80

#define TFTP_SERVER "107.160.244.5"
